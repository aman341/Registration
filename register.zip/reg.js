function validate()
{
    var result=true;
    var fname = document.getElementById("fname");
    if (fname.value.length==0)
    {
        alert("Please Enter the First Name");
        result=false;
        return(result);
    }

    var lname = document.getElementById("lname");
    if (lname.value.length==0)
    {
        alert("Please Enter the Last Name");
        result=false;
        return(result);
    }
    
    var phone = document.getElementById("phone");
    if (phone.value.length==0)
    {
        alert("Please Enter the Mobile Number");
        result=false;
        return(result);
    }

    var email = document.getElementById("email");
    if (email.value.length==0)
    {
        alert("Please Enter the Email");
        result=false;
        return(result);
    }

    var password = document.getElementById("password");
    if (password.value.length==0)
    {
        alert("Please Enter the Password");
        result=false;
        return(result);
    }
}